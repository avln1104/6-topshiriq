import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  int _currentIndex = 0;
  TextEditingController _textEditingController = TextEditingController();
  String _textValue = '';

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  void submitForm() {
    setState(() {
      _textValue = _textEditingController.text;
    });
  }

  @override
  void dispose() {
    _textEditingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: const Text("6-amaliy ish"),
          backgroundColor: Colors.green,
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 65,
              backgroundImage: NetworkImage(
                'https://example.com/image.jpg',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _textEditingController,
              decoration: InputDecoration(
                errorBorder: OutlineInputBorder(
                  borderSide: const BorderSide(
                    color: Colors.red,
                    width: 2,
                  ),
                ),
                errorText: "maydonni to'ldiring",
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () {
                submitForm();
                showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: const Text('Chiqarish'),
                      content: Text(_textValue),
                      actions: [
                        ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: const Text('Ok'),
                        ),
                      ],
                    );
                  },
                );
              },
              child: const Text(
                "Yuborish",
              ),
            ),
            const SizedBox(height: 12),
            Text(
              _textValue,
              style: TextStyle(
                color: Colors.red,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: onTabTapped,
          items: [
            BottomNavigationBarItem(
              icon: const Icon(Icons.home_filled),
              label: "Home",
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.search),
              label: "Search",
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.notifications),
              label: "Notifications",
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.person),
              label: "Profile",
            ),
          ],
        ),
      ),
    );
  }
}
